<?php
echo file_get_contents("dashboard.html");
?>
